import marshal
import zlib
import sys
import _frozen_importlib_external as bootstrap_ext
import C_file
import nxfilesystem
def println(*args, **kwargs):
    return

class CustomFileFinder:
    __doc__ = ' cloud '
    def __init__(self, path, *loader_details):
        loaders = []
        for loader, suffixes in loader_details:
            loaders.extend(((suffix, loader) for suffix in suffixes))
        self._loaders = loaders
        self.path = path
        self.file_system = nxfilesystem.get_filesystem('script')

    def find_spec(self, fullname, target=None):
        println('cff find_spec', fullname, target)
        tail_module = fullname.rpartition('.')[2]
        count = self.file_system.get_loader_count()
        for i in range(count):
            suffix = '.nxs3'
            loader_class = NXSLoader
            if self.file_system.get_loader_type(i) == 0:
                suffix = '.py'
                loader_class = SourceLoader
            file_path = bootstrap_ext._path_join(self.path, tail_module.replace('.', '/'))
            targets = [(file_path + '/__init__' + suffix, True), (file_path + suffix, False)]
            for fpath, is_package in targets:
                println('cff file try find', fpath)
                if self.file_system.find_file_by_loader(i, fpath, ''):
                    println('cff file exist', fpath)
                    _loader = loader_class(fullname, fpath)
                    _loader.loader_index = i
                    _loader.file_system = self.file_system
                    _location = fpath
                    if is_package:
                        sub = []
                    else:
                        sub = bootstrap_ext._POPULATE
                    spec = bootstrap_ext.spec_from_file_location(fullname, location=_location, loader=_loader, submodule_search_locations=sub)
                    spec.origin = self.file_system.get_loader_root(i) + '/' + fpath
                    return spec

    @classmethod
    def path_hook(cls, *loader_details):
        def path_hook_for_FileFinder(path):
            println('cff path_hook', path)
            return cls(*(path, *loader_details))
        return path_hook_for_FileFinder

class SourceLoader(bootstrap_ext.SourcelessFileLoader):
    def get_code(self, fullname):
        if bootstrap_ext._MS_WINDOWS:
            return self.get_code_win(fullname)
        path = self.get_filename(fullname)
        println('get_code_py', fullname, path)
        source_bytes = self.file_system.get_file_by_loader(self.loader_index, path, '')
        data = zlib.decompress(source_bytes)
        code_object = marshal.loads(data)
        return code_object

    def get_code_win(self, fullname):
        path = self.get_filename(fullname)
        root_path = self.file_system.get_loader_root(self.loader_index)
        println('get_code_py_win', fullname, path, root_path)
        try:
            source_path = root_path + '/' + path
            st = bootstrap_ext._path_stat(source_path)
            source_size, source_mtime = st.st_size, int(st.st_mtime)
        except:
            source_mtime, source_size = (0, 0)
        nxs_time = 0
        nxs_path = '__pycache__/' + path.replace('.py', '.nxs3')
        nxs_abs_path = root_path + '/' + nxs_path
        exist = self.file_system.find_file_by_loader(self.loader_index, nxs_path, '')
        if exist:
            try:
                data = self.file_system.get_file_by_loader(self.loader_index, nxs_path, '')
                bytes_data = memoryview(data)[16:]
                bootstrap_ext._validate_timestamp_pyc(data, source_mtime, source_size, nxs_path, {'name': nxs_path})
                code_object = marshal.loads(bytes_data)
                return code_object
            except:
                println('load nxs failed', nxs_path)
        source_bytes = self.file_system.get_file_by_loader(self.loader_index, path, '')
        code_object = compile(source_bytes, path, 'exec', dont_inherit=True, optimize=-1)
        data = bootstrap_ext._code_to_timestamp_pyc(code_object, source_mtime, len(source_bytes))
        self.set_data(nxs_abs_path, data)
        return code_object

    def set_data(self, path, data, *, _mode=438):
        parent, filename = bootstrap_ext._path_split(path)
        path_parts = []
        if parent and not bootstrap_ext._path_isdir(parent):
            parent, part = bootstrap_ext._path_split(parent)
            path_parts.append(part)
            if parent:
                if bootstrap_ext._path_isdir(parent):
                    pass
        for part in reversed(path_parts):
            parent = bootstrap_ext._path_join(parent, part)
            try:
                bootstrap_ext._os.mkdir(parent)
            except FileExistsError:
                continue
            except OSError as exc:
                return
            return
        try:
            bootstrap_ext._write_atomic(path, data, _mode)
        except OSError as exc:
            pass

class NXSLoader(bootstrap_ext.SourcelessFileLoader):
    def get_code(self, fullname):
        path = self.get_filename(fullname)
        println('get_code_nxs', fullname, path)
        source_bytes = self.file_system.get_file_by_loader(self.loader_index, path, '')
        data = zlib.decompress(source_bytes)
        code_object = marshal.loads(data)
        return code_object

def _get_supported_file_loaders():
    source = (SourceLoader, ['.py'])
    nxs = (NXSLoader, ['.nxs3'])
    return [nxs, source]

supported_loaders = _get_supported_file_loaders()
sys.path_hooks.insert(0, CustomFileFinder.path_hook(*supported_loaders))
println(sys.path_hooks)